export class ShowHistoryOfQueryDto {
  id: number;
  id_tipo_consulta: number;
  codigo: string;
  conjunto_dados: string;
  custo: number;
  consultado_por: number;
  ip_origem: string;
  tipo_dado: string;
  chave: string;
  resultado: string;
  data: Date;
}
