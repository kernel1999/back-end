import { Module } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios'; // Importe o HttpModule
import { FindCnpjService } from './find-cnpj.service';
import { FindCnpjController } from './find-cnpj.controller';
import { TypeOfQueryModule } from './../type-of-query/type-of-query.module';
import { HistoryOfQueryModule } from './../history-of-query/history-of-query.module';
import { UsersModule } from './../users/users.module';

@Module({
  imports: [
    HttpModule, // Certifique-se de importar o HttpModule aqui
    TypeOfQueryModule,
    HistoryOfQueryModule,
    UsersModule,
  ],
  controllers: [FindCnpjController],
  providers: [FindCnpjService],
})
export class FindCnpjModule {}
