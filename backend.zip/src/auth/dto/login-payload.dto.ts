// src/auth/dto/login-payload.dto.ts
export class LoginPayload {
    userId: number;
    username: string;
    role: string;
  }
  