export enum SroucesEnum {
  Admin = 'ADMIN',
  Site = 'SITE',
}
