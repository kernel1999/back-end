export enum Role {
  User = 'USER',
  Admin = 'ADMIN',
  SuperAdmin = 'SUPERADMIN',
}
