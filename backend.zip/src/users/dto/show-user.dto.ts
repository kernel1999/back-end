export class ShowUserDto {
  userId: number;
  username: string;
  role: string;
}
